import React, { Component } from 'react';

class Launch extends Component {

  render() {

    let launch = this.props.launch;

    return (
      <button className="collapsible">{ launch.mission_name }</button>
      <div className="content">
        {/* Add mission critical data here */}
        {/* <h2> { launch.mission_name } </h2> */}
        <div> { launch.rocket.rocket_name } </div>
        <div > { launch.rocket.rocket_id } </div>
      </div>
    );
  }
}

export default Launch;